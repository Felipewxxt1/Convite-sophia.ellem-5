<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>Convite da Sophia 💙</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
      margin: 0;
      font-family: 'Comic Sans MS', cursive;
      background: linear-gradient(to top, #c2f0ff, #ffffff);
      overflow: hidden;
      position: relative;
    }
    .container {
      position: relative;
      text-align: center;
      padding-top: 40px;
      z-index: 10;
    }
    h1 {
      color: #1c3d7a;
      font-size: 32px;
      margin-bottom: 10px;
    }
    p {
      font-size: 18px;
      color: #333;
      margin: 5px 0;
    }
    .stitch {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 150px;
      animation: moveStitch 10s infinite linear;
      z-index: 5;
    }
    @keyframes moveStitch {
      0% { left: -150px; transform: scaleX(1); }
      50% { left: calc(100% - 150px); transform: scaleX(1); }
      51% { transform: scaleX(-1); }
      100% { left: -150px; transform: scaleX(-1); }
    }
    .botao {
      background-color: #1abc9c;
      color: white;
      border: none;
      padding: 15px 25px;
      border-radius: 30px;
      font-size: 18px;
      cursor: pointer;
      margin-top: 20px;
      box-shadow: 2px 2px 10px rgba(0,0,0,0.2);
      transition: background 0.3s;
    }
    .botao:hover {
      background-color: #16a085;
    }

    /* Balões */
    .baloon {
      position: fixed;
      bottom: -100px;
      width: 40px;
      height: 60px;
      background: radial-gradient(circle at 20px 20px, #ff5c5c, #c80000);
      border-radius: 20px 20px 25px 25px;
      opacity: 0.8;
      animation-name: fall;
      animation-timing-function: linear;
      animation-iteration-count: infinite;
      z-index: 0;
    }
    .baloon:before {
      content: '';
      position: absolute;
      bottom: -8px;
      left: 50%;
      width: 2px;
      height: 10px;
      background: #555;
      transform: translateX(-50%);
    }
    @keyframes fall {
      0% {
        transform: translateY(0) rotate(0deg);
        opacity: 1;
      }
      100% {
        transform: translateY(110vh) rotate(360deg);
        opacity: 0;
      }
    }
  </style>
</head>
<body>

<audio autoplay loop>
  <source src="https://www.televisiontunes.com/uploads/audio/Xuxa%20-%20Parabens.mp3" type="audio/mpeg" />
  Seu navegador não suporta áudio.
</audio>

<div class="container">
  <h1>🎉 Sophia Ellen vai fazer 5 aninhos!</h1>
  <p>📅 Data: 17 de agosto de 2025</p>
  <p>🕛 Horário: A partir do meio-dia</p>
  <p>📍 Local: Av. Olímpico Domingos Cardoso, 607 – Fênix</p>
  <p>🎈 Tema: Stitch soltando balões e muita diversão!</p>
  <button class="botao" onclick="confirmarPresenca()">Confirmar Presença</button>
</div>

<img class="stitch" src="https://media.tenor.com/GGmGJObzB84AAAAi/stitch-dancing.gif" alt="Stitch dançando">

<script>
  function confirmarPresenca() {
    window.open("https://wa.me/5531985964011?text=Olá!%20Quero%20confirmar%20presença%20na%20festa%20da%20Sophia!", "_blank");
  }

  document.querySelector("audio").volume = 0.4;

  const cores = ['#ff5c5c', '#f9d71c', '#6ac1ff', '#ff85b3', '#9bff91'];
  const baloes = [];

  function criarBalao() {
    const balao = document.createElement('div');
    balao.classList.add('baloon');
    balao.style.background = `radial-gradient(circle at 20px 20px, ${cores[Math.floor(Math.random() * cores.length)]}, #c80000)`;
    balao.style.left = Math.random() * 100 + 'vw';
    balao.style.width = 30 + Math.random() * 20 + 'px';
    balao.style.height = 40 + Math.random() * 30 + 'px';
    balao.style.animationDuration = (5 + Math.random() * 5) + 's';
    document.body.appendChild(balao);
    baloes.push(balao);

    setTimeout(() => {
      balao.remove();
      baloes.splice(baloes.indexOf(balao), 1);
    }, 10000);
  }

  setInterval(criarBalao, 500);
</script>

</body>
</html>
